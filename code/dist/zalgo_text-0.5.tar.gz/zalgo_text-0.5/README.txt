To use first:

from zalgo_text import zalgo

then you can do something like:

print(zalgo.zalgofy("Some text to zalgofy"))
