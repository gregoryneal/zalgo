To use first:

import zalgo

then you can do something like:

print(zalgo.zalgofy("Some text to zalgofy"))